﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Quiz_System
{
    public partial class Teacher_Evaluation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["id"] != null)
            //{
            //    this.Master.FindControl("LoginBar").Visible = false;
            //    this.Master.FindControl("LogoutBar").Visible = true;
            //    // username.text = session["id"].tostring();
            //}
            //else
            //{
            //    // this.master.findcontrol("logoutbar").visible = false;
            //    // this.master.findcontrol("loginbar").visible = true;
            //    Response.Redirect("~/Login.aspx");
            //}
            string[] students = Directory.GetFiles(System.AppDomain.CurrentDomain.BaseDirectory + "/Data/Students", "*", SearchOption.TopDirectoryOnly);
            foreach (string file in students)
            {
                StudentData s = StudentData.ReadStudent(file);
                for (int i = 0; i < s.QuizIDs.Count; i++)
                {

                    PC.Controls.Add(new Literal() { Text = "<br/>" });
                    PC.Controls.Add(new Literal() { Text = "<br/>" });
                    Label studentname = new Label();
                    studentname.Style.Add("text-align", "left");
                    studentname.Text = Session["id"].ToString();
                    PC.Controls.Add(studentname);
                    PC.Controls.Add(new Literal() {Text = "<hr/>" });
                    Label ID = new Label();
                    ID.Style.Add("text-align", "left");
                    ID.Text = s.QuizIDs[i].ToString();
                    PC.Controls.Add(ID);
                    Label name = new Label();
                    name.Style.Add("text-align", "center");
                    name.Text = s.QuizNames[i].ToString();
                    PC.Controls.Add(name);
                    Label score = new Label();
                    score.Style.Add("text-align", "center");
                    score.Text = s.QuizScores[i].ToString() + "/" + s.QuizMaxScore[i].ToString();
                    PC.Controls.Add(score);
                    PC.Controls.Add(new Literal() {Text = "<br/>" });
                }

            }
        }
    }
}