﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Quiz_System
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["id"] != null)
            {
                this.Master.FindControl("LoginBar").Visible = false;
                this.Master.FindControl("LogoutBar").Visible = true;
            }
            else
            {
                this.Master.FindControl("LogoutBar").Visible = false;
                this.Master.FindControl("LoginBar").Visible = true;
            }
        }

        protected void Contact_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Contact");
        }
    }
}