﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Quiz_System
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void login_Click(object sender, EventArgs e)
        {
            //string user = "Your name is " + username.Value;
            //ltMessage.Text = user;
            //TeacherInfo(1, username.Value, pass.Value);
            var Log = QuizFast.Login(username.Value, pass.Value);
            if (Log.type != null)
            {
                if (Log.type == "Teacher")
                {
                    Session["id"] = Log.name;
                    Response.Redirect("~/Teacher");
                }
                if (Log.type == "Student")
                {
                    Session["id"] = Log.name;
                    Response.Redirect("~/Student.aspx?ID=" + Server.UrlEncode(Log.id.ToString()));
                }
            }
            else
            {
                ltMessage.Text = "Wrong Email or Password";
            }
            //Session["id"] = username.Value;
            // Session.RemoveAll();
            
        }
    }

}